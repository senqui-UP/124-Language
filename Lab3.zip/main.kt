fun main() {
    println("Loading...")
    println("Welcome to PyCraft (type '/kill' to exit)")

    val interpreter = Interpreter()

    while (true) {
        print("> ")
        val input = readln()
        if (input.trim() == "/kill") break

        val scanner = Scanner(input)
        val tokens = scanner.scanTokens()
        val parser = Parser(tokens)

        try {
            if (input.trim().startsWith("/")) {
                val statements = parser.parseStatements()
                for (stmt in statements) interpreter.execute(stmt)
            } else {
                val expr = parser.parseExpression()
                val value = interpreter.evaluate(expr)
                println(interpreter.stringify(value))
            }
        } catch (e: RuntimeError) {
            val line = e.token?.line ?: 1
            println("[line $line] Runtime error: ${e.message}")
        } catch (e: Exception) {
            println(e.message)
        }
    }
}
